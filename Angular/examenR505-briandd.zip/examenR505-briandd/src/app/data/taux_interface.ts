export interface TauxInterface {
    duree: number;
    valeur: number;
}