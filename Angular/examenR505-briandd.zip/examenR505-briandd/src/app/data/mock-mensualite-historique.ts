import { Historique } from "./historique_interface";

export let HISTO: Historique[] = [
    {montant: 1,duree:1,taux:1,mensualite:1}
];