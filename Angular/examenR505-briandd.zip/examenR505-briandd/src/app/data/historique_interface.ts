export interface Historique {
    montant: number;
    duree: number;
    taux: number;
    mensualite:number;
}