import { TauxInterface } from './taux_interface';

export const TAUX: TauxInterface[] = [
    {duree:10,valeur:1.91},
    {duree:15,valeur:2.16},
    {duree:20,valeur:2.41},
    {duree:25,valeur:2.7},
];