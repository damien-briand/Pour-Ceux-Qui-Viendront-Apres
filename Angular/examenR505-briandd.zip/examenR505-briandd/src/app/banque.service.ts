import { Injectable } from '@angular/core';
import { TauxInterface } from './data/taux_interface';
import { TAUX } from './data/mock-taux-actuels';
import { Observable, of } from 'rxjs';
import { HISTO } from './data/mock-mensualite-historique';
import { Historique } from './data/historique_interface';

@Injectable({
  providedIn: 'root'
})
export class BanqueService {

  constructor() { }

  getTaux(): Observable<TauxInterface[]> {
    const taux = of(TAUX);
    return taux;
  }

  getHistorique(): Observable<Historique[]>{
    const h = of(HISTO)
    return h;
  }

  addHisto(mont:number, d:number, t:number, mens:number):void {
    const addLine: Historique = {
      montant:mont,
      duree:d,
      taux:t,
      mensualite:mens
    };
    HISTO.push(addLine)
  }

  /**
   * Retourne la mensualité en fonction du montant en euros, du taux (pourcentage) et de la durée en année
   */
  calculMensualite(montant: number, taux: number, duree: number) {
    var haut: number;
    var bas: number;

    // Calcule de la mensualité
    haut = montant * ((taux/100)/12);
    bas = 1 - Math.pow(1 + ((taux/100)/12), -(duree*12));
    return Math.round((haut/bas)*100)/100;
  }

}
