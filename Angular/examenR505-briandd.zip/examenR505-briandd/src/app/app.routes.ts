import { Routes } from '@angular/router';
import { AccueilComponent } from './accueil/accueil.component';
import { CalculComponent } from './calcul/calcul.component';
import { HistoriqueComponent } from './historique/historique.component';

export const routes: Routes = [
    { path: '', redirectTo: '/accueil', pathMatch: 'full' },
    { path: 'accueil', component: AccueilComponent },
    { path: 'calcul', component: CalculComponent },
    { path: 'historique', component: HistoriqueComponent },
];
