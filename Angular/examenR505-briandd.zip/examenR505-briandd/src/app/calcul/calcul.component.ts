import { Component, OnInit } from '@angular/core';
import { BanqueService } from '../banque.service';
import { RouterLink } from '@angular/router';
import { FormsModule, ReactiveFormsModule ,FormGroup, FormControl, Validators } from '@angular/forms';
import { TauxInterface } from '../data/taux_interface';
import { NgFor } from '@angular/common';

@Component({
  selector: 'app-calcul',
  standalone: true,
  imports: [FormsModule, ReactiveFormsModule, RouterLink, NgFor],
  templateUrl: './calcul.component.html',
  styleUrl: './calcul.component.css'
})
export class CalculComponent implements OnInit{
  tauxForm: FormGroup;
  taux: TauxInterface[] = []
  allMensualite: number[] = []

  constructor(
    private banqueService: BanqueService,
  ) {
    this.tauxForm = new FormGroup({
      montant : new FormControl('', [Validators.required,Validators.min(0)]),
    });
  }

  ngOnInit(): void {
    this.getTaux()
  }

  getTaux(): void{
    this.banqueService.getTaux().subscribe((t) => this.taux = t)
  }

  getMensualite(montant:number): void{
    this.allMensualite = []
    for (let index = 0; index < this.taux.length; index++) {
      this.allMensualite.push(this.banqueService.calculMensualite(montant,this.taux[index].valeur, this.taux[index].duree))
    }
  }

  getResult(): void{
    this.getMensualite(this.tauxForm.value.montant)
  }

  addToHisto():void {
    
  }
}
