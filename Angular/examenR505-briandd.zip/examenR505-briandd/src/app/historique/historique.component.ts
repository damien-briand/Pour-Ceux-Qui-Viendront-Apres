import { Component, OnInit } from '@angular/core';
import { BanqueService } from '../banque.service';
import { Historique } from '../data/historique_interface';

@Component({
  selector: 'app-historique',
  standalone: true,
  imports: [],
  templateUrl: './historique.component.html',
  styleUrl: './historique.component.css'
})
export class HistoriqueComponent implements OnInit{

  histo: Historique[] = []
  constructor(private banqueService: BanqueService) {}

  ngOnInit(): void {
    this.getHisto() 
  }

  getHisto():void {
    this.banqueService.getHistorique().subscribe((h) => this.histo = h)
  }
}
