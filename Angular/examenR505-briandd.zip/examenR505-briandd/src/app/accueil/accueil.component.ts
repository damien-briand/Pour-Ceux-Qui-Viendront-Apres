import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { NgFor } from '@angular/common';
import { BanqueService } from '../banque.service';
import { TauxInterface } from '../data/taux_interface';

@Component({
  selector: 'app-accueil',
  standalone: true,
  imports: [NgFor, RouterLink],
  templateUrl: './accueil.component.html',
  styleUrl: './accueil.component.css'
})
export class AccueilComponent implements OnInit{

  taux: TauxInterface[] = []
  constructor(private banqueService: BanqueService) {}

  ngOnInit(): void {
    this.getTaux()
  }

  getTaux(): void{
    this.banqueService.getTaux().subscribe((t) => this.taux = t)
  }

}
